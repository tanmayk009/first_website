
package src;

public interface DistanceMeasure {
	
	public double DistanceBetween(FeatureVector obj1, FeatureVector obj2);
	
}
